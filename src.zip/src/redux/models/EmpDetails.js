class EmpDetails {
    constructor(id, name, age, salary) {
      this.id = id;
      this.name = name;
      this.age = age;
      this.salary = salary;
    }
  }
  
  export default EmpDetails;